# Simple Blog App using Laravel
Simple App to apply CRUD operations and ability to login via Gmail / Github

## Project setup
- Create new mysql database called "laravel" and run :
```
npm install
```
```
php artisan migrate:fresh
```
## Run the Project
```
php artisan serve
```
# Demo

https://user-images.githubusercontent.com/72516521/169620821-450039fd-d8f5-4112-85cc-00925ecbf242.mp4

